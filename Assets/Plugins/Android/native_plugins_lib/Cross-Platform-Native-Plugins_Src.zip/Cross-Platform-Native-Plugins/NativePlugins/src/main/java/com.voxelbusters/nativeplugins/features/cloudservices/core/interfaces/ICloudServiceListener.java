package com.voxelbusters.nativeplugins.features.cloudservices.core.interfaces;

public interface ICloudServiceListener
{
	public void onReceivingCloudData(String jsonData, String accountName);

	public void onReceivingErrorOnLoad();

	public void onCommittingCloudData(boolean success, String committedData);
}
