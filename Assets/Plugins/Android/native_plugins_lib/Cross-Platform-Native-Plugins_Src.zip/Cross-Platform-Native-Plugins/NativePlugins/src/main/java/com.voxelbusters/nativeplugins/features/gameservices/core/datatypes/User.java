package com.voxelbusters.nativeplugins.features.gameservices.core.datatypes;

import com.voxelbusters.nativeplugins.defines.Keys;

import java.util.HashMap;

/**
 * Created by ayyappa on 11/05/16.
 */
public class User
{
    public String identifier;
    public String name;
    public String alias;
    public String highResImageUrl;
    public String iconImageUrl;
    public long timeStamp;

    public HashMap<String, Object> getHashMap()
    {
        HashMap<String, Object> hash = new HashMap<String, Object>();

        hash.put(Keys.GameServices.USER_ID, identifier);
        hash.put(Keys.GameServices.USER_NAME, name);
        hash.put(Keys.GameServices.USER_ALIAS, alias);
        hash.put(Keys.GameServices.USER_HIGH_RES_IMAGE_URL, highResImageUrl);
        hash.put(Keys.GameServices.USER_ICON_IMAGE_URL, iconImageUrl);
        hash.put(Keys.GameServices.USER_TIME_STAMP, timeStamp);

        return  hash;
    }
}
