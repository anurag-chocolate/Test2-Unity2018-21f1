package com.voxelbusters.nativeplugins.features.gameservices.core.interfaces;

import com.voxelbusters.nativeplugins.features.gameservices.core.datatypes.User;

import java.util.HashMap;

public interface IGameServicesAuthListener
{
	/*
	 Return details of the logged in player once logged in. Return error description on error.
	*/
	void onConnected(User player, String error);// Signin

	/*
	 Called once there is a disconnection.
	*/
	void onDisConnected();// Signout

	/*
	 Called once connection is suspended.
	*/
	void onConnectionSuspended();

	/*
	 Called once connection is failed.
	*/
	void onConnectionFailure();

	/*
	 Called once user signed out (manually from default UI provided by the service).
	*/
	void onSignOut(String error);


	/*
	 Called for sending external auth details once loaded.
	*/
	void onReceivingExternalAuthenticationDetails(String authCode, String error);
}
