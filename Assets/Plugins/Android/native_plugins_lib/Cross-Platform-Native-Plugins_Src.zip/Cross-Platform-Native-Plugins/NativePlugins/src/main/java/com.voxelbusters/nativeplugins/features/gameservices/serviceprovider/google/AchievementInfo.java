package com.voxelbusters.nativeplugins.features.gameservices.serviceprovider.google;

import com.google.android.gms.games.achievement.Achievement;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import java.util.HashMap;

/**
 * Created by ayyappa on 12/05/16.
 */
public class AchievementInfo
{
    public String	identifier;
    public String	name;
    public String	description;
    public String	imagePath;
    public int		type;
    public int		currentSteps;
    public int		totalSteps;
    public int		state;
    public long	lastReportedDate;
    public boolean	isCompleted;

    AchievementInfo(Achievement achievement)
    {
        identifier = achievement.getAchievementId();
        name = achievement.getName();
        description = achievement.getDescription();
        imagePath = getImagePathForAchievement(achievement);
        type = achievement.getType();
        state = achievement.getState();

        if (type == Achievement.TYPE_INCREMENTAL)
        {
            currentSteps = achievement.getCurrentSteps();
            totalSteps = achievement.getTotalSteps();
        }
        else
        {
            currentSteps = (state == Achievement.STATE_UNLOCKED) ? 1 : 0;
            totalSteps = 1;
        }

        lastReportedDate = achievement.getLastUpdatedTimestamp();
        isCompleted = (achievement.getState() == Achievement.STATE_UNLOCKED);

    }

    void SetCurrentSteps(int _steps)
    {
        currentSteps = _steps;
    }

    public String getImagePathForAchievement(Achievement achievement)
    {
        String _imagePath = "";
        String _unlockedImageUrl = achievement.getUnlockedImageUrl();
        String _revealedImageUrl = achievement.getRevealedImageUrl();

        if (StringUtility.isNullOrEmpty(_unlockedImageUrl))
        {
            if (!StringUtility.isNullOrEmpty(_revealedImageUrl))
            {
                _imagePath = _revealedImageUrl;
            }
        }
        else
        {
            _imagePath = _unlockedImageUrl;
        }

        return _imagePath;
    }

    public String getStateForAchievement()
    {

        String stateStr = Keys.GameServices.STATE_HIDDEN;

        if (state == Achievement.STATE_UNLOCKED)
        {
            stateStr = Keys.GameServices.STATE_UNLOCKED;
        }
        else if (state == Achievement.STATE_REVEALED)
        {
            stateStr = Keys.GameServices.STATE_REVEALED;
        }
        else if (state == Achievement.STATE_HIDDEN)
        {
            stateStr = Keys.GameServices.STATE_HIDDEN;
        }

        return stateStr;
    }

    public String getTypeForAchievement()
    {
        String _typeStr = Keys.GameServices.TYPE_STANDARD;

        if (type == Achievement.TYPE_STANDARD)
        {
            _typeStr = Keys.GameServices.TYPE_STANDARD;
        }
        else if (type == Achievement.TYPE_INCREMENTAL)
        {
            _typeStr = Keys.GameServices.TYPE_INCREMENTAL;
        }

        return _typeStr;
    }

    @Override
    public String toString ()
    {
        return  "identifier : " + identifier + "   " +
                "name : " + name + "   " +
                "description : " + description + "   " +
                "imagePath : " + imagePath + "   " +
                "type : " + type + "   " +
                "currentSteps : " + currentSteps + "   " +
                "totalSteps : " + totalSteps + "   " +
                "state : " + state + "   " +
                "lastReportedDate : " + lastReportedDate + "   " +
                "isCompleted : " + isCompleted + "   " ;
    }
}