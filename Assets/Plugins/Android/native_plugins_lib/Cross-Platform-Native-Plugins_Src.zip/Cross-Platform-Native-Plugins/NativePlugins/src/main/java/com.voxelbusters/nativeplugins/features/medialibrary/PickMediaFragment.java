package com.voxelbusters.nativeplugins.features.medialibrary;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.webkit.MimeTypeMap;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.FileUtility;
import com.voxelbusters.nativeplugins.utilities.IntentUtilities;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by ayyappa on 29/01/18.
 */

public class PickMediaFragment extends Fragment implements Camera.PictureCallback
{

    public static final String	CAMERA_CAPTURE_FILE_NAME		= "mediaPicker-camera-image";
    public static final int		REQUEST_CODE_UNKNOWN			= -1;
    public static final int		REQUEST_CODE_LIBRARY_ACCESS		= 1;
    public static final int		REQUEST_CODE_CAMERA_ACCESS		= 2;

    int 						MAX_IMAGE_SIZE					= 2048;

    ArrayList<String> allowedTypes					= new ArrayList<String>();
    int currentRequestCode = REQUEST_CODE_UNKNOWN;
    boolean receivedActivityResult;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
            super.onCreate(savedInstanceState);

            if(savedInstanceState == null)
            {
                Bundle bundleInfo = getArguments();

                Intent requiredIntent = null;
                int requestCode = REQUEST_CODE_UNKNOWN;

                String type = bundleInfo.getString(Keys.TYPE);


                allowedTypes.clear();
                allowedTypes.add("jpeg");
                allowedTypes.add("jpg");
                allowedTypes.add("png");


                if (type.equals(MediaLibraryHandler.IMAGE_FROM_LIBRARY)) {
                    requiredIntent = IntentUtilities.getGalleryIntent("image/*");
                    requestCode = REQUEST_CODE_LIBRARY_ACCESS;
                } else if (type.equals(MediaLibraryHandler.IMAGE_FROM_CAMERA_INTENT) || type.equals((MediaLibraryHandler.IMAGE_FROM_CAMERA_API))) {
                    Uri imageUri = null;
                    imageUri = FileUtility.createSharingFileUri(this.getActivity(), null, 0, CommonDefines.SHARING_DIR, CAMERA_CAPTURE_FILE_NAME);

                    requiredIntent = IntentUtilities.getCameraIntent(this.getActivity(), imageUri);
                    requestCode = REQUEST_CODE_CAMERA_ACCESS;
                } else {
                    Debug.error(CommonDefines.MEDIAL_LIBRARY_TAG, "Unknown source specified! " + type);
                    finish();
                    return;
                }

                if (requiredIntent != null) {
                    Intent finalIntent = requiredIntent;

                    // Verify it resolves
                    PackageManager packageManager = getActivity().getPackageManager();
                    List<ResolveInfo> activities = packageManager.queryIntentActivities(requiredIntent, 0);
                    int availableIntentCount = activities.size();

                    if (availableIntentCount > 1 || availableIntentCount == 0)//Show empty list if no activities present as well for feedback. And also for showing available list.
                    {
                        finalIntent = Intent.createChooser(requiredIntent, Keys.MediaLibrary.SELECT_MEDIA);
                    }

                    launchActivityForResult(finalIntent, requestCode);
                }
            }
            else
            {
                currentRequestCode = savedInstanceState.getInt("REQUEST_CODE");
            }
        }

        void launchActivityForResult(Intent intent, int requestCode)
        {
            currentRequestCode = requestCode;
            startActivityForResult(intent, requestCode);
        }

        @Override
        public void onSaveInstanceState(Bundle outState)
        {
            super.onSaveInstanceState(outState);
            outState.putInt("REQUEST_CODE",currentRequestCode);
        }

        @Override
        public void onConfigurationChanged(Configuration newConfig)
        {
            super.onConfigurationChanged(newConfig);
        }

        @Override
        public void onDestroy()
        {
            Debug.log(CommonDefines.MEDIAL_LIBRARY_TAG, "OnDestroy MeidaLibraryActivity");

            if ((currentRequestCode != REQUEST_CODE_UNKNOWN) && !receivedActivityResult)
            {
                switch(currentRequestCode)
                {
                    case 	REQUEST_CODE_LIBRARY_ACCESS:
                            REQUEST_CODE_CAMERA_ACCESS:

                        MediaLibraryHandler.getInstance().sendPickImageResult(null, Keys.MediaLibrary.PICK_IMAGE_CANCELLED);
                        break;
                    default:
                        Debug.error(CommonDefines.MEDIAL_LIBRARY_TAG, "Unknown request code!");

                        break;
                }
            }

            super.onDestroy();
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent intent)
        {
            super.onActivityResult(requestCode, resultCode, intent);

            boolean finishActivity = true;
            switch (requestCode)
            {
                case REQUEST_CODE_LIBRARY_ACCESS:

                    if ((resultCode == Activity.RESULT_OK) && (intent != null))
                    {
                        Uri selectedImgUri = intent.getData();

                        Debug.log(CommonDefines.MEDIAL_LIBRARY_TAG, "Uri : " + selectedImgUri.toString());

                        createAsycTaskForImageCopy(selectedImgUri);
                        finishActivity = false;
                    }
                    else
                    {
                        Debug.log(CommonDefines.MEDIAL_LIBRARY_TAG, "resultCode " + resultCode);

                        MediaLibraryHandler.getInstance().sendPickImageResult(null, Keys.MediaLibrary.PICK_IMAGE_CANCELLED);

                    }
                    break;
                case REQUEST_CODE_CAMERA_ACCESS:

                    File imageFileDestination = FileUtility.getFileProviderUriFile(getActivity(),CommonDefines.SHARING_DIR, CAMERA_CAPTURE_FILE_NAME);
                    FileUtility.limitImageToMaxResolution(getActivity(), MAX_IMAGE_SIZE,Uri.fromFile(imageFileDestination), Uri.fromFile(imageFileDestination));


                    if ((resultCode == Activity.RESULT_OK) && imageFileDestination.exists())
                    {
                        MediaLibraryHandler.getInstance().sendPickImageResult(imageFileDestination.getAbsolutePath(), Keys.MediaLibrary.PICK_IMAGE_SELECTED);
                    }
                    else
                    {
                        MediaLibraryHandler.getInstance().sendPickImageResult(null, Keys.MediaLibrary.PICK_IMAGE_CANCELLED);
                    }

                    break;
                default:
                    Debug.error(CommonDefines.MEDIAL_LIBRARY_TAG, "Unknown request code!");

                    break;
            }
            receivedActivityResult = true;

            if (finishActivity)
                finish();

        }

        //Create an sync task for copying the image
        void createAsycTaskForImageCopy(final Uri selectedImageUri)
        {
            new AsyncTask<String, Void, String>()
            {

                @Override
                protected String doInBackground(String... params)
                {
                    InputStream inputStream = null;
                    String fileType = "";
                    try
                    {
                        Debug.log(CommonDefines.MEDIAL_LIBRARY_TAG, selectedImageUri.toString());
                        ContentResolver contentResolver = getActivity().getContentResolver();
                        MimeTypeMap mime = MimeTypeMap.getSingleton();
                        fileType = mime.getExtensionFromMimeType(contentResolver.getType(selectedImageUri)).toLowerCase(Locale.ENGLISH);

                        inputStream = contentResolver.openInputStream(selectedImageUri);

                    }
                    catch (FileNotFoundException e)
                    {
                        e.printStackTrace();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                    String timeStamp = StringUtility.getCurrentTimeStamp();
                    String destFileName = "Library_Image_" + timeStamp;

                    String absoluteDestinationFilePath = null;

                    if (allowedTypes.contains(fileType))
                    {
                        absoluteDestinationFilePath = FileUtility.createFileFromStream(inputStream, ApplicationUtility.getLocalSaveDirectory(getActivity(), "MediaLibrary"), destFileName);
                    }
                    else
                    {
                        Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, null);
                        absoluteDestinationFilePath = FileUtility.getScaledImagePathFromBitmap(bitmap, ApplicationUtility.getLocalSaveDirectory(getActivity(), "MediaLibrary"), destFileName, 1.0f);
                    }

                    FileUtility.limitImageToMaxResolution(getActivity(), MAX_IMAGE_SIZE,Uri.fromFile(new File(absoluteDestinationFilePath)),selectedImageUri);

                    // Force System GC
                    System.gc();

                    return absoluteDestinationFilePath;
                }

                @Override
                protected void onPostExecute(String result)
                {
                    MediaLibraryHandler.getInstance().sendPickImageResult(result, Keys.MediaLibrary.PICK_IMAGE_SELECTED);
                    finish();
                }

            }.execute(null, null, null);
        }

        @Override
        public void onPictureTaken(byte[] bytes, Camera camera)
        {
        }


        private void finish()
        {
            FragmentTransaction fragmentTransaction = getActivity().getFragmentManager().beginTransaction();
            fragmentTransaction.remove(this);
            fragmentTransaction.commit();
        }
}