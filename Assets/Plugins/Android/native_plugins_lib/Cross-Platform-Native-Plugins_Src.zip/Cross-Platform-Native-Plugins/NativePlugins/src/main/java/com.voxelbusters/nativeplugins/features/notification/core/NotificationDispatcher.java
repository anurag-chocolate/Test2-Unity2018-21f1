package com.voxelbusters.nativeplugins.features.notification.core;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.RingtoneManager;
import android.os.Build;
import android.renderscript.RenderScript;
import android.support.v4.app.NotificationCompat;

import com.voxelbusters.nativeplugins.externallibrary.notification.shortcutbadger.ShortcutBadger;
import com.voxelbusters.NativeBinding;
import com.voxelbusters.androidnativeplugin.R;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.defines.UnityDefines;
import com.voxelbusters.nativeplugins.features.notification.NotificationHandler.NotificationType;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.JSONUtility;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import static android.support.v4.app.NotificationManagerCompat.IMPORTANCE_HIGH;

public class NotificationDispatcher
{
	Context		context;
	MediaPlayer	mediaPlayer;

	public NotificationDispatcher(Context context)
	{
		this.context = context;
	}

	public void dispatch(JSONObject notificationData, boolean isRemoteNotification)
	{

		if (isRemoteNotification && NotificationDefines.usesExtenralRemoteNotificationService(context))
		{
			return;// Don't do any if user opts for external notification service.
		}

		JSONObject keyMap = NotificationDefines.getKeysInfo(context);
		Debug.log(CommonDefines.NOTIFICATION_TAG, "Current keymapping used is " + keyMap.toString());

		Debug.log(CommonDefines.NOTIFICATION_TAG, "notificationData " + notificationData.toString());

		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		String channelID = ApplicationUtility.getPackageName(context);

		// Oreo Update

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			NotificationChannel channel = new NotificationChannel(channelID,
					ApplicationUtility.getApplicationName(context),
					NotificationManager.IMPORTANCE_DEFAULT);
			notificationManager.createNotificationChannel(channel);
		}



		String appName = ApplicationUtility.getApplicationName(context);

		// If app is in foreground we don't need to push the notification in notification bar
		JSONObject formattedNotification = getFormattedNotification(notificationData, keyMap);

		String formattedNotificationString = formattedNotification.toString();

		boolean isAppRunning = NativePluginHelper.isApplicationRunning();
		boolean isAppForeground = NativeBinding.isApplicationForeground();

		if (!isAppRunning || !isAppForeground)
		{
			try
			{
				Intent notificationIntent = new Intent(context, ApplicationLauncherFromNotification.class);//ApplicationUtility.GetMainLauncherActivity(context));

				notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP
						| Intent.FLAG_ACTIVITY_SINGLE_TOP);


				notificationIntent.putExtra(Keys.Notification.NOTIFICATION_PAYLOAD, formattedNotificationString);
				notificationIntent.putExtra(Keys.Notification.IS_REMOTE_NOTIFICATION, isRemoteNotification);

				PendingIntent pendingIntent = PendingIntent.getActivity(context.getApplicationContext(), (int)System.currentTimeMillis(), notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
				String contentTitle = notificationData.optString(keyMap.getString(NotificationDefines.CONTENT_TITLE), null);
				String contentText = notificationData.optString(keyMap.getString(NotificationDefines.CONTENT_TEXT), null);
				String tickerText = notificationData.optString(keyMap.getString(NotificationDefines.TICKER_TEXT), null);
				String notificationTag = notificationData.optString(keyMap.getString(NotificationDefines.TAG), null);
				int badgeCount = notificationData.optInt(keyMap.getString(NotificationDefines.BADGE), 0);


				String customSoundName = notificationData.optString(keyMap.getString(NotificationDefines.CUSTOM_SOUND), "");
				String largeIconName = notificationData.optString(keyMap.getString(NotificationDefines.LARGE_ICON), "");

				NotificationCompat.Builder builder;
				Notification notification = null;
				try
				{
					builder = new NotificationCompat.Builder(context, channelID);
				}
				catch (Throwable e)
				{
					builder = new NotificationCompat.Builder(context);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
						Debug.error(CommonDefines.NOTIFICATION_TAG, "Make sure you are compiling with minimum 26.0.1 support libraries." + e);
					}
				}

				if (NotificationDefines.needsVibration(context))
				{
					builder.setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);
				}
				else
				{
					builder.setDefaults(Notification.DEFAULT_LIGHTS);
				}


				builder.setSmallIcon(context.getApplicationInfo().icon);

				if (NotificationDefines.needsCustomIconDrawing(context))
				{
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
					{
						builder.setSmallIcon(R.drawable.app_icon_custom_white);
					}
					else
					{
						builder.setSmallIcon(R.drawable.app_icon_custom_coloured);
					}
				}

				//Set large icon now.
				Bitmap customLargeIcon = getCustomLargeIconBitmap(largeIconName);
				if (customLargeIcon != null)
				{
					builder.setLargeIcon(customLargeIcon);
				}

				builder.setWhen(System.currentTimeMillis());
				builder.setAutoCancel(true);
				builder.setContentIntent(pendingIntent);

				if (NotificationDefines.hasNotificationType(NotificationType.Sound, context))
				{
					if (StringUtility.isNullOrEmpty(customSoundName))
					{
						builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
					}
					else
					{
						PlayCustomNotificationSound(customSoundName);
					}
				}

				// Apply badge count
				if (NotificationDefines.hasNotificationType(NotificationType.Badge, context))
				{
					try
					{
						ShortcutBadger.applyCount(context, badgeCount);
						builder.setNumber(badgeCount);//For support from Android 8
					}
					catch (Exception e)
					{
						Debug.error(CommonDefines.NOTIFICATION_TAG, "Exception :" + e);
					}
				}

				if (!StringUtility.isNullOrEmpty(contentText))
				{
					if (NotificationDefines.hasNotificationType(NotificationType.Alert, context))
					{
						builder.setTicker(tickerText);

						String title = (contentTitle == null) ? appName : contentTitle;
						builder.setContentTitle(title);
						builder.setContentText(contentText);

						// Setting big notification
						builder.setStyle(new NotificationCompat.BigTextStyle().bigText(contentText));
						notification = builder.build();

					}
					else
					{
						Debug.error(CommonDefines.NOTIFICATION_TAG, "Alerts off. No Notification type was set");
					}
				}
				else
				{
					Debug.warning(CommonDefines.NOTIFICATION_TAG, "No data for content text to show in notification bar! key : " + keyMap.getString(NotificationDefines.CONTENT_TEXT));
					if (Debug.ENABLED)
					{
						builder.setContentText("No Message!!!");
						notification = builder.build();
					}
				}

				if (notification != null)
				{
					int identifier = ApplicationUtility.getApplicationName(context).hashCode();
					notificationManager.notify(notificationTag, identifier, notification);

					/*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
					{
						if (service != null)
						{
							service.startForeground(identifier, notification);
						}
					}*/
				}

			}
			catch (JSONException e)
			{
				e.printStackTrace();
			}

		}
		else
		{
			// TODO make this a single point of calling. App launch and this.
			if (isRemoteNotification)
			{
				NativePluginHelper.sendMessage(UnityDefines.Notification.DID_RECEIVE_REMOTE_NOTIFICATION, formattedNotificationString);
			}
			else
			{
				NativePluginHelper.sendMessage(UnityDefines.Notification.DID_RECEIVE_LOCAL_NOTIFICATION, formattedNotificationString);
			}
		}
	}

	JSONObject getFormattedNotification(JSONObject notificationData, JSONObject keyMap)
	{
		JSONObject formattedNotification = null;

		try
		{

			formattedNotification = new JSONObject(notificationData, JSONUtility.getKeys(notificationData));

			formattedNotification.put(keyMap.getString(NotificationDefines.FIRE_DATE), System.currentTimeMillis());

			if (formattedNotification.has(keyMap.getString(NotificationDefines.USER_INFO)))
			{
				try
				{
					String userInfoString = formattedNotification.getString(keyMap.getString(NotificationDefines.USER_INFO));
					formattedNotification.remove(keyMap.getString(NotificationDefines.USER_INFO));
					formattedNotification.put(keyMap.getString(NotificationDefines.USER_INFO), new JSONObject(userInfoString));
				}
				catch (Exception e)
				{
					Debug.error(CommonDefines.NOTIFICATION_TAG, "UserInfo Data should be a dictionary");
					Debug.error(CommonDefines.NOTIFICATION_TAG, e.getMessage());
				}
			}

		}
		catch (JSONException e)
		{
			e.printStackTrace();
			formattedNotification = new JSONObject();
		}

		return formattedNotification;

	}

	Bitmap getCustomLargeIconBitmap(String largeIconName)
	{
		if (!StringUtility.isNullOrEmpty(largeIconName))
		{
			Bitmap largeIcon = null;
			InputStream stream = null;

			int resourceId = ApplicationUtility.getResourceId(context, largeIconName.toLowerCase(Locale.US), "raw");

			if (resourceId == 0)
			{

				stream = getLargeIconStreamFromAssetsFolder(CommonDefines.PROJECT_ASSETS_FOLDER_OLD + largeIconName);

				if (stream == null)
				{
					Debug.error(CommonDefines.NOTIFICATION_TAG, "Custom icon set for notification not found. Make sure it is kept in " + CommonDefines.PROJECT_ASSETS_EXPECTED_FOLDER);
				}
			}
			else
			{
				stream = context.getResources().openRawResource(resourceId);
			}

			largeIcon = BitmapFactory.decodeStream(stream);

			return largeIcon;
		}
		else
		{
			return null;
		}
	}

	void PlayCustomNotificationSound(String customSoundName)
	{
		if (!StringUtility.isNullOrEmpty(customSoundName))
		{
			AssetFileDescriptor assetFileDescriptor = null;
			try
			{
				//get the resource id from the file name  
				int resourceId = ApplicationUtility.getResourceId(context, customSoundName.toLowerCase(Locale.US), "raw");

				if (resourceId == 0)
				{
					//Check deprecated path for backward compat
					assetFileDescriptor = getCustomNotificationSoundFromAssetsFolder(customSoundName);

					if (assetFileDescriptor == null)
					{
						Debug.error(CommonDefines.NOTIFICATION_TAG, "Expecting " + customSoundName + " in " + CommonDefines.PROJECT_ASSETS_EXPECTED_FOLDER);
					}
				}
				else
				{
					assetFileDescriptor = context.getResources().openRawResourceFd(resourceId);
				}

				//Start media player directly.
				mediaPlayer = new MediaPlayer();
				mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
				mediaPlayer.setAudioStreamType(AudioManager.STREAM_NOTIFICATION);
				mediaPlayer.prepare();
				mediaPlayer.start();

				mediaPlayer.setOnCompletionListener(new OnCompletionListener()
					{
						@Override
						public void onCompletion(MediaPlayer player)
						{
							player.release();
						}
					});

				assetFileDescriptor.close();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}

	}

	AssetFileDescriptor getCustomNotificationSoundFromAssetsFolder(String customSoundName)
	{
		AssetFileDescriptor assetFileDescriptor = null;

		AssetManager assetManager = context.getAssets();

		try
		{
			assetFileDescriptor = assetManager.openFd((CommonDefines.PROJECT_ASSETS_FOLDER_OLD) + customSoundName);
			Debug.error(CommonDefines.NOTIFICATION_TAG, "This path for custom sounds is deprecated! Keep your files in " + CommonDefines.PROJECT_ASSETS_EXPECTED_FOLDER);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

		return assetFileDescriptor;
	}

	@Deprecated
	InputStream getLargeIconStreamFromAssetsFolder(String path)
	{
		InputStream stream = null;
		try
		{
			stream = context.getAssets().open(path);
			Debug.error(CommonDefines.NOTIFICATION_TAG, "This path for custom large icon is deprecated! Keep your files in " + CommonDefines.PROJECT_ASSETS_EXPECTED_FOLDER);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return stream;
	}
}