package com.voxelbusters.nativeplugins.features.notification.serviceprovider.gcm;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import com.voxelbusters.nativeplugins.features.notification.core.NotificationDefines;
import com.voxelbusters.nativeplugins.features.notification.core.NotificationJobService;

//Reference from Android docs
public class GCMBroadcastReceiver extends BroadcastReceiver
{
	@Override
	public void onReceive(Context context, Intent intent)
	{
		if (!NotificationDefines.usesExtenralRemoteNotificationService(context))
		{
			// Explicitly specify that GCMIntentService will handle the intent.
			ComponentName comp = new ComponentName(context.getPackageName(), GCMIntentService.class.getName());
			intent.setComponent(comp);
			NotificationJobService.enqueueWork(context, intent);
		}
	}
}
