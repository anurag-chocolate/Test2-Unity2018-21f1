package com.voxelbusters.nativeplugins.helpers.interfaces;

/**
 * Created by ayyappa on 25/09/17.
 */

public interface IPermissionRequestCallback
{
    void onPermissionGrant();
    void onPermissionDeny();
}
